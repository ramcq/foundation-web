#!/usr/bin/perl

use Digest::MD5 qw (md5_hex);
use MD5;

die "Usage: mail-ballots.pl <mail archive> <secret string> <bad token list>\n" unless $#ARGV == 2;

my $SECRET_STRING = $ARGV[1];

open MBOX, "<$ARGV[0]" || die "Cannot open file $ARGV: $!";
@mbox_lines = <MBOX>;
close MBOX;

open RECIPS, "<$ARGV[2]" || die "Cannot open file $ARGV: $!";
while (<RECIPS>) {
    chomp; 
    next if (/^\#/ || /^$/);

    if (!(/(.*)\/(.*)\/(.*)/)) {
        print "Error for line: $_\n";
        next;
    }
    my $identity = $1;
    my $addr = $2;
    my $bad_hash = $3;
    my $good_hash = MD5->hexhash ("$identity $addr", $SECRET_STRING);

    s/$bad_hash/$good_hash/g foreach (@mbox_lines);
}
close RECIPS;

open FIXED_MBOX, ">$ARGV[0].fixed" || die "Cannot open file ". $ARGV[0].".fixed: $!";
print FIXED_MBOX @mbox_lines;
close FIXED_MBOX;
